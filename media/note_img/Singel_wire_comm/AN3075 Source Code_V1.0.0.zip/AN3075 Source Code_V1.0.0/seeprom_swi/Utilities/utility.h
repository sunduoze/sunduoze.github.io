/** \file
 *  \brief Header file for utility.c.
 */

/***************************************************************************************************************************************************************************
    (c) 2019 Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip
    software and any derivatives exclusively with Microchip products. It is
    your responsibility to comply with third party license terms applicable to
    your use of third party software (including open source software) that may
    accompany Microchip software.

    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY
    IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS
    FOR A PARTICULAR PURPOSE.

    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP
    HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO
    THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL
    CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT
    OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS
    SOFTWARE.
***************************************************************************************************************************************************************************/

#ifndef _UTILITY_H_
#define _UTILITY_H_

#include "config.h"

#define ERR_CMD_BUF_FULL    1

void Send_Error_Message( uint8_t ErrorCodes );
uint8_t Ascii_to_nible ( uint8_t ucData );
uint8_t Nible_to_ascii ( uint8_t ucData );
void uart_usb_puthex_array( uint8_t * pBuf, uint8_t ucLength );
void uart_usb_puthex_16 ( uint16_t ucData16 );


uint8_t ConvertNibbleToAscii (uint8_t nibble);
uint8_t ConvertAsciiToNibble (uint8_t ascii);
uint8_t ConvertAsciiToBinary (uint8_t length, uint8_t * buffer);
uint8_t ExtractDataLoad (char *command, uint8_t * dataLength,uint8_t ** data);
uint8_t ExtractOpCode(char *command, uint8_t *dataLength, uint8_t **dataBuf);
#endif // UTILITY_H
