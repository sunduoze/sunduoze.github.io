/** \file
 *  \brief Data converter functions
 */

/***************************************************************************************************************************************************************************
    (c) 2019 Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip
    software and any derivatives exclusively with Microchip products. It is
    your responsibility to comply with third party license terms applicable to
    your use of third party software (including open source software) that may
    accompany Microchip software.

    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY
    IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS
    FOR A PARTICULAR PURPOSE.

    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP
    HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO
    THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL
    CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT
    OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS
    SOFTWARE.
***************************************************************************************************************************************************************************/

#include <string.h>
#include "utility.h"


/** \brief Converting Nible to ASCII
 *
 * \param ucData is nible data to be converted
 *
 * \return ucData is the ASCII value
**/
uint8_t Nible_to_ascii ( uint8_t ucData )
{
    ucData &= 0x0F;
    if (ucData <= 0x09 )
    {
        ucData += '0';
    }
    else
    {
        ucData = ucData - 10 + 'A';
    }
    return ucData;
}

/** \brief Converting ASCII to Nible
 *
 * \param ucData is the ASCII value to be converted
 *
 * \return ucData is the nible value
**/
uint8_t Ascii_to_nible ( uint8_t ucData )
{
    if ((ucData <= '9' ) && (ucData >= '0')) 
    {
        ucData -= '0';
    }
    else if ((ucData <= 'F' ) && (ucData >= 'A')) 
    {
        ucData = ucData -'A' + 10;
    }
    else if ((ucData <= 'f' ) && (ucData >= 'a')) 
    {
        ucData = ucData -'a' + 10;
    }
    else 
    {
        ucData = 0;
    }
    return ucData;
}

/** \brief This function converts a nibble to Hex-ASCII.
 * \param[in] nibble nibble value to be converted
 * \return ASCII value
**/
uint8_t
ConvertNibbleToAscii (uint8_t nibble)
{
  nibble &= 0x0F;
  if (nibble <= 0x09)
    nibble += '0';
  else
    nibble += ('A' - 10);
  return nibble;
}


/** \brief This function converts an ASCII character to a nibble.
 * \param[in] ascii ASCII value to be converted
 * \return nibble value
**/
uint8_t ConvertAsciiToNibble(uint8_t ascii)
{
    if ((ascii <= '9') && (ascii >= '0'))
        ascii -= '0';
    else if ((ascii <= 'F' ) && (ascii >= 'A'))
        ascii -= ('A' - 10);
    else if ((ascii <= 'f') && (ascii >= 'a'))
        ascii -= ('a' - 10);
    else
        ascii = 0;
    return ascii;
}


/** \brief This function converts binary data to ASCII.
 * \param[in] length number of bytes in buffer
 * \param[in, out] buffer pointer to buffer
 * \return number of bytes in buffer
 */
uint8_t ConvertAsciiToBinary(uint8_t length, uint8_t *buffer)
{
	if (length < 2)
		return 0;

	uint8_t i, binIndex;
	uint8_t asciiBuffer[length];

	memcpy(asciiBuffer, buffer, length);

	for (i = 0, binIndex = 0; i < length; i += 2)
	{
		buffer[binIndex] = ConvertAsciiToNibble(asciiBuffer[i]) << 4;
		buffer[binIndex++] |= ConvertAsciiToNibble(asciiBuffer[i + 1]);
	}

	return --binIndex;
}