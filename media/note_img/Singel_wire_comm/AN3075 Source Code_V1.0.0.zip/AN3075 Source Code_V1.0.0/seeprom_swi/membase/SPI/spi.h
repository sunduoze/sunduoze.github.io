/***************************************************************************************************************************************************************************
FileName:			spi.h
Processor:			AT90USB1287
Compiler:			GNU Toolchain (3.6.1.1750)
IDE:				Atmel Studio 7.0.1645
Author:				Erik Fasnacht
Company:			Microchip Technology, Inc.

Summary:			Header file for spi.c
    
Description:		Header file for spi.c
***************************************************************************************************************************************************************************/

/***************************************************************************************************************************************************************************
    (c) 2019 Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip
    software and any derivatives exclusively with Microchip products. It is
    your responsibility to comply with third party license terms applicable to
    your use of third party software (including open source software) that may
    accompany Microchip software.

    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY
    IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS
    FOR A PARTICULAR PURPOSE.

    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP
    HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO
    THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL
    CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT
    OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS
    SOFTWARE.
***************************************************************************************************************************************************************************/

#ifndef _SPI_H_
#define _SPI_H_

#include "config.h"

//defgroup SPI_Macro SPI Macro for AT90USB646/7 and AT90USB1286/7
#if defined (__AVR_AT90USB646__) || defined (__AVR_AT90USB647__) || \
defined (__AVR_AT90USB1286__) || defined (__AVR_AT90USB1287__)
   #define Spi_sck_high  PORTB |= (1 << PB1)
   #define Spi_sck_low   PORTB &= ~(1 << PB1)
   #define Spi_ss_high   PORTB |= (1 << PB0)
   #define Spi_ss_low    PORTB &= ~(1 << PB0)
   #define Spi_timeout   ((F_CPU / 1000 / 1024) * 60)
#endif

void  Spi_initialize();
uchar Spi_send_and_receive(uchar ucData);

#endif // _SPI_H_