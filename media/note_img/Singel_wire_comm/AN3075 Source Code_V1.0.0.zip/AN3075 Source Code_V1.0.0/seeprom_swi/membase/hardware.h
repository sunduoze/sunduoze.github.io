/***************************************************************************************************************************************************************************
FileName:			hardware.h
Processor:			AT90USB1287
Compiler:			GNU Toolchain (3.6.1.1750)
IDE:				Atmel Studio 7.0.1645
Author:				Erik Fasnacht
Company:			Microchip Technology, Inc.

Summary:			Header file with port and pin definitions of USB Base Board
    
Description:		Header file with port and pin definitions of USB Base Board
***************************************************************************************************************************************************************************/

/***************************************************************************************************************************************************************************
    (c) 2019 Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip
    software and any derivatives exclusively with Microchip products. It is
    your responsibility to comply with third party license terms applicable to
    your use of third party software (including open source software) that may
    accompany Microchip software.

    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY
    IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS
    FOR A PARTICULAR PURPOSE.

    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP
    HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO
    THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL
    CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT
    OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS
    SOFTWARE.
***************************************************************************************************************************************************************************/

#ifndef _HARDWARE_H_
#define _HARDWARE_H_

#include "config.h"
#include "compiler.h"

//define the ADC used to set the voltage on the SI/O pin
#define ADCCS 		         PC6  //OUTPUT
#define ADCCS_DDR 		     DDRC  
#define ADCCS_PORT			 PORTC
#define LDAC 		         PE6  //OUTPUT
#define LDAC_DDR 		     DDRE
#define LDAC_PORT			 PORTE
#define CSDAC 		         PB6  //OUTPUT
#define CSDAC_DDR 		     DDRB
#define CSDAC_PORT			 PORTB

//define the HWB Button
#define  Hwb_button_init()    (DDRE  &= ~(1<<PINE2), PORTE |= (1<<PINE2))
#define  Is_hwb()             ((PINE &   (1<<PINE2)) ?  FALSE : TRUE)
#define  Is_not_hwb()         ((PINE &   (1<<PINE2)) ?  TRUE : FALSE)

//define the DAC control signals
#define gpio_set_pin_high(port,pin) (port |= (1<<pin))
#define gpio_set_pin_low(port,pin)  (port &= ~(1<<pin))
#define gpio_set_pin_dir_output(port,pin) (port |= (1<<pin))

//define LEDs
#define  LED_PORT             PORTD
#define  LED_DDR              DDRD
#define  LED_PIN              PIND

#define  LED1_BIT             PD6
#define  LED2_BIT             PD5
#define  LED3_BIT             PD4
#define  BUZZER_BIT           PD7

#define  LEDS_INIT          (LED_DDR  |=  (1<<LED1_BIT) | (1<<LED2_BIT) |(1<<LED3_BIT))
#define  LED_ALL_ON         (LED_PORT |=  (1<<LED1_BIT) | (1<<LED2_BIT)| (1<<LED3_BIT))
#define  LED_ALL_OFF        (LED_PORT &= ~((1<<LED1_BIT) | (1<<LED2_BIT)| (1<<LED3_BIT)))

#define  LED1_ON            (LED_PORT |=  (1<<LED1_BIT))
#define  LED2_ON            (LED_PORT |=  (1<<LED2_BIT))
#define  LED3_ON            (LED_PORT |=  (1<<LED3_BIT))

#define  LED1_OFF           (LED_PORT &= ~(1<<LED1_BIT))
#define  LED2_OFF           (LED_PORT &= ~(1<<LED2_BIT))
#define  LED3_OFF           (LED_PORT &= ~(1<<LED3_BIT))

#define  LED1_toggle()      (LED_PIN  |=  (1<<LED1_BIT))
#define  LED2_toggle()      (LED_PIN  |=  (1<<LED2_BIT))
#define  LED3_toggle()      (LED_PIN  |=  (1<<LED3_BIT))

#define  Is_LED1_ON()       (LED_PIN  &   (1<<LED1_BIT) ? TRUE : FALSE)
#define  Is_LED2_ON()       (LED_PIN  &   (1<<LED2_BIT) ? TRUE : FALSE)
#define  Is_LED3_ON()       (LED_PIN  &   (1<<LED3_BIT) ? TRUE : FALSE)		 

#endif