/*******************************************************************************
FileName:			operations.c
Processor:			PIC16F1719
Compiler:			XC8 v2.05
IDE:				MPLABX IDE v5.20
Author:				Erik Fasnacht
Company:			Microchip Technology, Inc.

Summary:			Functions for various operations in single-wire protocol
    
Description:		This file includes functions for the various operations used
                    by the AT21CS Series devices.
*******************************************************************************/
/*******************************************************************************
    (c) 2019 Microchip Technology Inc. and its subsidiaries. 
    
    Subject to your compliance with these terms, you may use Microchip software
    and any derivatives exclusively with Microchip products. It is your  
    responsibility to comply with third party license terms applicable to your
    use of third party software (including open source software) that may
    accompany Microchip software.
    
    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER 
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY 
    IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS 
    FOR A PARTICULAR PURPOSE.
    
    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP 
    HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO 
    THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL 
    CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT 
    OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS 
    SOFTWARE.
*******************************************************************************/

//******************************************************************************
//******************************************************************************               
//Include Declarations
#include "mcc_generated_files/mcc.h"
#include "low-level.h"
#include "operations.h"

//******************************************************************************
//******************************************************************************        
//Scan for Slave Address Routine
uint8_t scanDeviceAddress(){

    uint8_t temp;
    uint8_t address;
    
    for(uint8_t ii =0; ii < 8; ii++)            //loop for all 8 slave addresses
	{
		if(discoveryResponse() == 0)            //perform device discovery
		{
			startHS();                          //start condition 
			temp = ii;
			temp <<= 1;                         //shift address to proper bit position
			temp |= 0xA0;                       //add EEPROM op code and set R/W = 0		 
			if(txByte(temp) == 0x00)            //If the device ACKs
			{
				address = ii;                   //set slave address equal to loop count
				address <<= 1;                  //shift address to proper bit position
				startHS();                      //start condition 
				break;                          //break from loop
			}
		}
	}

printf("    Slave Address = ");                 //TX character string over UART
if (address == 0x00)    {printf("000b\n");}     //TX character string over UART
if (address == 0x02)    {printf("001b\n");}     //TX character string over UART 
if (address == 0x04)    {printf("010b\n");}     //TX character string over UART 
if (address == 0x06)    {printf("011b\n");}     //TX character string over UART 
if (address == 0x08)    {printf("100b\n");}     //TX character string over UART 
if (address == 0x0A)    {printf("101b\n");}     //TX character string over UART 
if (address == 0x0C)    {printf("110b\n");}     //TX character string over UART 
if (address == 0x0E)    {printf("111b\n");}     //TX character string over UART 

return address;                                 //return ACK'd slave address
}

//******************************************************************************
//******************************************************************************                       
//Write Sequence
void eepromwrite(uint8_t dByte, uint8_t aByte, uint8_t writeData[],uint8_t count){
    
    dByte |= slaveAddress;                      //set slave address 
    
    startHS();                                  //start condition    
    txByte(dByte);                              //Device Address Byte     
    txByte(aByte);                              //Word Address Byte
    for (uint8_t ii = 0; ii < count; ii++)	{   //loop for data to be written
        txByte(writeData[ii]);                  //Data Byte(s) to be written   
    }
    startHS();                                  //stop condition
    __delay_ms(5);                              //tWC Delay  
}

//******************************************************************************
//******************************************************************************                       
//Random Address Read Sequence
void randomRead(uint8_t dByte, uint8_t aByte, uint8_t *readData, uint8_t count){

    dByte |= slaveAddress;                      //set slave address                

    startHS();                                  //start condition    
    txByte(dByte);                              //Device Address Byte     
    txByte(aByte);                              //Word Address Byte
    startHS();                                  //start condition 
    txByte((uint8_t)(dByte | 0x01));            //Device Address Byte
    for (uint8_t ii = 0; ii < count; ii++)	{   //loop for bytes to be written         
        readData[ii] = readByte();              //read a byte 
        if (ii < (count-1)) {   tx0();  }       //send an ACK
    }    
    tx1();                                      //send a NACK
    startHS();                                  //stop condition

    printf("    Data Read =");                  //TX character string over UART
    for (uint8_t ii = 0; ii < count; ii++)  {
        printf(" 0x");                          //TX character string over UART
        printf("%02X", readData[ii]);           //"%02X" for two char ^case hex
    }
    printf("\n");                               //create a new line
}

//******************************************************************************
//******************************************************************************                       
//Current Address Read Sequence
void currentRead(uint8_t dByte, uint8_t *readData, uint8_t count){

    dByte |= slaveAddress;                      //set slave address                

    startHS();                                  //start condition 
    txByte((uint8_t)(dByte | 0x01));            //Device Address Byte
    for (uint8_t ii = 0; ii < count; ii++)	{   //loop for bytes to be written         
        readData[ii] = readByte();              //read a byte 
        if (ii < (count-1)) {   tx0();  }       //send an ACK	
    }   
    tx1();                                      //send a NACK
    startHS();                                  //stop condition

    printf("    Data Read =");                  //TX character string over UART
    for (uint8_t ii = 0; ii < count; ii++)  {
        printf(" 0x");                          //TX character string over UART
        printf("%02X", readData[ii]);           //"%02X" for two char ^case hex
    }
    printf("\n");                               //create a new line   
}

//******************************************************************************
//******************************************************************************                       
//Lock Security Register Sequence  (Permanent Operation)
void SRLock(){
    
    startHS();                                  //start condition    
    txByte((uint8_t)(0x20 | slaveAddress));     //Device Address Byte     
    txByte(0x60);                               //Word Address Byte
    txByte(0x00);                               //Data Byte to be written   
    startHS();                                  //stop condition
    __delay_ms(5);                              //tWC Delay  
}


//******************************************************************************
//******************************************************************************                       
//Check Security Register Lock Sequence
uint8_t readSRLock(){
    uint8_t temp = 0xAA;          

    startHS();                                  //start condition 
    txByte((uint8_t)(0x20 | slaveAddress));     //Device Address Byte
    temp = txByte(0x60);                        //Word Address Byte
    
    if (temp == 0x00)   {
        printf("    Security Reg. Unlocked\n"); //TX character string over UART
    }    
    else    {
        printf("    Security Reg. Locked\n");   //TX character string over UART
    }
    
    startHS();                                  //stop condition    
return temp;    
}

//******************************************************************************
//******************************************************************************                       
//Lock ROM Zone Sequence  (Permanent Operation)
void setROM(uint8_t aByte){
    
    startHS();                                  //start condition    
    txByte((uint8_t)(0x70 | slaveAddress));     //Device Address Byte     
    txByte(aByte);                              //Word Address Byte
    txByte(0xFF);                               //Data Byte to be written   
    startHS();                                  //stop condition
    __delay_ms(5);                              //tWC Delay  
}

//******************************************************************************
//******************************************************************************                       
//Freeze ROM Zones Sequence (Permanent Operation)
void freezeROM(){
    
    startHS();                                  //start condition    
    txByte((uint8_t)(0x10 | slaveAddress));     //Device Address Byte     
    txByte(0x55);                               //Word Address Byte
    txByte(0xAA);                               //Data Byte to be written   
    startHS();                                  //stop condition
    __delay_ms(5);                              //tWC Delay  
}

//******************************************************************************
//******************************************************************************                       
//Read ROM Zone Lock Status Sequence
uint8_t readROM(uint8_t aByte){
    
    uint8_t dByte = (uint8_t)(0x70 | slaveAddress);
    uint8_t temp = 0xAA;          

    startHS();                                  //start condition 
    txByte(dByte);                              //Device Address Byte
    txByte(aByte);                              //Word Address Byte
    startHS();                                  //start condition 
    txByte((uint8_t)(dByte | 0x01));            //Device Address Byte
    temp = readByte();                          //read a byte 
    
    if (aByte == 0x01)  {
        if (temp == 0x00)   {
            printf("    ROM Zone0 Unlocked\n"); //TX character string over UART
        }    
        else    {
            printf("    ROM Zone0 Locked\n");   //TX character string over UART
        }
    }
    
    if (aByte == 0x02)  {
        if (temp == 0x00)   {
            printf("    ROM Zone1 Unlocked\n"); //TX character string over UART
        }    
        else    {
            printf("    ROM Zone1 Locked\n");   //TX character string over UART
        }
    }
    
    if (aByte == 0x04)  {
        if (temp == 0x00)   {
            printf("    ROM Zone2 Unlocked\n"); //TX character string over UART
        }    
        else    {
            printf("    ROM Zone2 Locked\n");   //TX character string over UART
        }
    }
    
    if (aByte == 0x08)  {
        if (temp == 0x00)   {
            printf("    ROM Zone3 Unlocked\n");     //TX character string over UART
        }    
        else    {
            printf("    ROM Zone3 Locked\n");       //TX character string over UART
        }
    }
        
    startHS();                                  //stop condition    
return temp;    
}

//******************************************************************************
//******************************************************************************                       
//Set Communication Speed Sequence
uint8_t setCommuncationSpeed(uint8_t dByte){
    
    uint8_t temp;
    dByte |= slaveAddress;                      //set slave address                

    startHS();                                  //start condition 
    temp = txByte((uint8_t)(dByte));            //Device Address Byte
    startHS();                                  //stop condition
    if (((dByte & 0xF0) == 0xD0) & (temp == 0x00)){
        communicationSpeed = 1;
    }
    else    {
        communicationSpeed = 0;
    }
return temp;   
}

//******************************************************************************
//******************************************************************************                       
//Check Communication Speed Sequence
uint8_t checkCommuncationSpeed(uint8_t dByte){
    
    uint8_t temp;
    dByte |= slaveAddress;                      //set slave address                

    startHS();                                  //start condition 
    temp = txByte((uint8_t)(dByte|0x01));       //Device Address Byte
    startHS();                                  //stop condition

    if(temp == 0x00){                           //if device ACKs
        if((dByte & 0xF0) == 0xD0){
            printf("    Standard Speed ACK\n"); //TX character string over UART
        }
        if((dByte & 0xF0) == 0xE0){
            printf("    High-Speed ACK\n");     //TX character string over UART
        }          
    }
    else    {                                   //if device NACKs
        if((dByte & 0xF0) == 0xD0){
            printf("    Standard Speed NACK\n");//TX character string over UART
        }
        if((dByte & 0xF0) == 0xE0){
            printf("    High-Speed NACK\n");    //TX character string over UART
        }          
    }
return temp;    
}