/*******************************************************************************
FileName:			main.c
Processor:			PIC16F1719
Compiler:			XC8 v2.05
IDE:				MPLABX IDE v5.20
Author:				Erik Fasnacht
Company:			Microchip Technology, Inc.

Summary:			AT21CS Series Single-Wire Example Solution
    
Description:		This solution shows a simple Single-Wire implementation of
					writing to and reading from an AT21CS Series Serial EEPROM
					using a PIC16F1719 MCU. Hardware used in creating this
					example solution is the Explorer 8 Development Board
*******************************************************************************/
/*******************************************************************************
    (c) 2019 Microchip Technology Inc. and its subsidiaries. 
    
    Subject to your compliance with these terms, you may use Microchip software
    and any derivatives exclusively with Microchip products. It is your
    responsibility to comply with third party license terms applicable to your
    use of third party software (including open source software) that may
    accompany Microchip software.
    
    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY
    IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS
    FOR A PARTICULAR PURPOSE.
    
    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP
    HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO
    THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL
    CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT
    OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS
    SOFTWARE.
*******************************************************************************/

//******************************************************************************
//******************************************************************************
//Include Declarations
#include "mcc_generated_files/mcc.h"
#include "operations.h"
#include "low-level.h"

//******************************************************************************
//******************************************************************************               
//global variable declarations
uint8_t slaveAddress = 0x00;                    //slave address = 000b (initial)
uint8_t communicationSpeed = 0;                 //0=high-speed; 1=Standard

//******************************************************************************
//******************************************************************************         
//******************************************************************************
//******************************************************************************
//Main Application
void main(void)
{
    
    SYSTEM_Initialize();                        //MCC, initialize the device

// When using interrupts, set the Global and Peripheral Interrupt Enable bits
// Use the following macros to:
    INTERRUPT_GlobalInterruptEnable();          //enable Global Interrupts
    INTERRUPT_PeripheralInterruptEnable();      //enable Peripheral Interrupts
    //INTERRUPT_GlobalInterruptDisable();       //disable Global Interrupts
    //INTERRUPT_PeripheralInterruptDisable();   //disable Peripheral Interrupts

    while (1)
    {
        
//******************************************************************************
//******************************************************************************              
//SI/O Initialization               
        SIO_SetOpenDrain();                     //sets SIO pin to be open drain
        SIO_SetHigh();                          //initial set HIGH for SI/O
        SIO_SetDigitalOutput();                 //sets SI/O pin to be digital
        
//******************************************************************************
//******************************************************************************              
//Variable Declaration   
        uint8_t writeData0[8] = {0x00,0x11,0x22,0x33,0x44,0x55,0x66,0x77};
        uint8_t writeData1[8] = {0x88,0x99,0xAA,0xBB,0xCC,0xDD,0xEE,0xFF};
        uint8_t readPORData[8] = { 0 };
        uint8_t readData0[8] = { 0 };
        uint8_t readData1[8] = { 0 };
        uint8_t snData[8] = { 0 };
        uint8_t idData0[8] = { 0 };
        uint8_t idData1[8] = { 0 };
        uint8_t readROM0 = 0xAA;
        uint8_t readROM1 = 0xAA; 
        uint8_t readROM2 = 0xAA; 
        uint8_t readROM3 = 0xAA; 
                
//******************************************************************************
//******************************************************************************                
//Setup for hardware breakpoint using the S2 explorer 8 button (top left button).  
//When the button is pressed, the code below will run.    
        while (S2_GetValue() != 0);             //Switch 2S debounce             
        while (S2_GetValue() == 0);             //Switch S2 pressed test
                 
        printf("\n");                           //TX character string over UART
        printf("AN3304 Source Code\n");         //TX character string over UART
        printf("Revision Date: 12-19-2019\n");  //TX character string over UART

//******************************************************************************
//******************************************************************************        
//Scan for Slave Address and Reset and Discovery      
        printf("\n");                           //TX character string over UART
        printf("Slave Address Scan\n");         //TX character string over UART
        slaveAddress = scanDeviceAddress();     //sets ACK'd slave address
        
//******************************************************************************
//******************************************************************************        
//Current Address Read after Reset and Discovery (read @ address 0x00)       
        printf("\n");                           //TX character string over UART
        printf("Current Read After Reset\n");   //TX character string over UART
        currentRead(0xA0, readPORData, 8);      //current read after reset
        
//******************************************************************************
//******************************************************************************        
//Standard Speed Communication  
        printf("\n");                           //TX character string over UART
        printf("Set Standard Speed Comm.\n");   //TX character string over UART
        setCommuncationSpeed(0xD0);        
        checkCommuncationSpeed(0xD0);
        
        printf("\n");                           //TX character string over UART
        printf("Standard Speed Write/Read\n");  //TX character string over UART
        eepromwrite(0xA0, 0x00, writeData0, 8);       //page write @ address 0x00        
        randomRead(0xA0, 0x00, readData0, 8);   //read 8 bytes @ address 0x00

//******************************************************************************
//******************************************************************************        
//High-Speed Communication    
        printf("\n");                           //TX character string over UART
        printf("Set High-Speed Comm.\n");       //TX character string over UART
        setCommuncationSpeed(0xE0);
        checkCommuncationSpeed(0xE0);
        
        printf("\n");                           //TX character string over UART
        printf("High-Speed Write/Read\n");  //TX character string over UART
        eepromwrite(0xA0, 0x08, writeData1, 8);       //page write @ address 0x08
        randomRead(0xA0, 0x08, readData1, 8);   //read 8 bytes @ address 0x08
        
//******************************************************************************
//******************************************************************************        
//Security Register Sequences
        printf("\n");                           //TX character string over UART
        printf("Serial Number Read\n");         //TX character string over UART
        randomRead(0xB0, 0x00, snData, 8);      //read the 64-bit serial number
        
        printf("\n");                           //TX character string over UART
        printf("Write/Read ID Page0\n");        //TX character string over UART
        eepromwrite(0xB0, 0x10, writeData0, 8);       //write data to first ID page
        randomRead(0xB0, 0x10, idData0, 8);     //read both ID pages
        
        printf("\n");                           //TX character string over UART
        printf("Write/Read ID Page1\n");        //TX character string over UART
        eepromwrite(0xB0, 0x18, writeData1, 8);       //write data to second ID page
        randomRead(0xB0, 0x18, idData1, 8);     //read both ID pages
               
//******************************************************************************
//******************************************************************************                
//Permanent Operations (Hold S1 button While pressing S2 button to perform)
        if (S1_GetValue() == 0) {               //perform Permanent Operations
            printf("\n");                       //TX character string over UART
            printf("Lock Security Register\n"); //TX character string over UART
            SRLock();                           //lock Security Register
            readSRLock();                       //read the SR Lock State
            printf("\n");                       //TX character string over UART
            printf("Lock ROM Zone 1 and 3\n");  //TX character string over UART
            setROM(0x02);                       //Lock Zone1
            setROM(0x08);                       //Lock Zone3
            printf("\n");                       //TX character string over UART
            printf("Freeze ROM Zones\n");       //TX character string over UART
            freezeROM();                        //Freeze all ROM Zone States
            printf("\n");                       //TX character string over UART
            printf("Read ROM Zones\n");         //TX character string over UART
            readROM0 = readROM(0x01);           //read lock status of ROM Zone0
            readROM1 = readROM(0x02);           //read lock status of ROM Zone1
            readROM2 = readROM(0x04);           //read lock status of ROM Zone2
            readROM3 = readROM(0x08);           //read lock status of ROM Zone3            
        }                 
    }                 
}
/**
 End of File
*/