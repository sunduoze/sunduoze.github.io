#include "type_b_led.h"

static void on(void)
{
    printf("type_b on\r\n");
}
static void off(void)
{
    printf("type_b off\r\n");
}

led_if_t b_led = {
    on,
    off,
};
