#ifndef LED_H_
#define LED_H_

typedef struct
{
    void (*on)(void);
    void (*off)(void);
}led_if_t;

void register_led(led_if_t led);
void led_on(void);
void led_off(void);

#endif // LED_H_INCLUDED
