#ifndef TYPE_A_LED_H_
#define TYPE_A_LED_H_

#include "led.h"

//extern led_if_t a_led;
led_if_t a_led;
extern void test(void);

#endif // TYPE_A_LED_H_INCLUDED
