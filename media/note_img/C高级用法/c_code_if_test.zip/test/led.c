#include "led.h"

static led_if_t led_if;

void register_led(led_if_t led)
{
    led_if = led;
}

void led_on(void)
{
    led_if.on();
}

void led_off(void)
{
    led_if.off();
}
