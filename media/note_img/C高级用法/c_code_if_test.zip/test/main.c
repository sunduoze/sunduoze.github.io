#include <stdio.h>
#include <stdint.h>

#include "led.h"
#include "type_a_led.h"
#include "type_b_led.h"


int main()
{
    register_led(a_led);
    led_on();
    led_off();

    register_led(b_led);
    led_on();
    led_off();

    return 0;
}
