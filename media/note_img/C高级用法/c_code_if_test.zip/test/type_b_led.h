#ifndef TYPE_B_LED_H_
#define TYPE_B_LED_H_

#include "led.h"

led_if_t b_led;


#endif // TYPE_B_LED_H_INCLUDED
